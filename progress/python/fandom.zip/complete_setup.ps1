# ==============================================================================
# Fandom Community Platform - Complete Automated Setup Script
# ==============================================================================
# Version: 1.0.0
# Date: 2025-10-17
# Description: Automated setup for multi-tenant community platform
# Features: One-command deployment for localhost and production
# ==============================================================================

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("development", "production")]
    [string]$Environment = "development",

    [Parameter(Mandatory=$false)]
    [string]$ProjectPath = "fandom_community_platform",

    [Parameter(Mandatory=$false)]
    [string]$DatabaseName = "fandom_communities",

    [Parameter(Mandatory=$false)]
    [string]$DatabaseUser = "postgres",

    [Parameter(Mandatory=$false)]
    [string]$DatabasePassword = "",

    [Parameter(Mandatory=$false)]
    [switch]$SkipDatabase,

    [Parameter(Mandatory=$false)]
    [switch]$AutoCreateSuperuser
)

# Color functions for output
function Write-ColorOutput {
    param([string]$Message, [string]$Color = "White")
    Write-Host $Message -ForegroundColor $Color
}

function Write-Success { param([string]$Message) Write-ColorOutput "✓ $Message" "Green" }
function Write-Info { param([string]$Message) Write-ColorOutput "ℹ $Message" "Cyan" }
function Write-Warning { param([string]$Message) Write-ColorOutput "⚠ $Message" "Yellow" }
function Write-Error { param([string]$Message) Write-ColorOutput "✗ $Message" "Red" }
function Write-Step { param([string]$Message) Write-ColorOutput "▶ $Message" "Magenta" }

# Banner
Clear-Host
Write-ColorOutput @"
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║         FANDOM COMMUNITY PLATFORM - AUTOMATED SETUP                  ║
║                                                                      ║
║  Multi-Tenant │ Subdomain Communities │ Django Wiki │ PostgreSQL    ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
"@ "Cyan"

Write-Info "Environment: $Environment"
Write-Info "Project Path: $ProjectPath"
Write-Info "Database: $DatabaseName"
Write-Host ""

# Step 1: Prerequisites Check
Write-Step "Step 1: Checking Prerequisites"
Write-Host ""

# Check Python
try {
    $pythonVersion = python --version 2>&1 | Out-String
    if ($pythonVersion -match "Python (\d+\.\d+\.\d+)") {
        $version = $matches[1]
        Write-Success "Python $version detected"
    }
} catch {
    Write-Error "Python not found! Please install Python 3.9+ from python.org"
    exit 1
}

# Check PostgreSQL
if (-not $SkipDatabase) {
    try {
        $pgVersion = psql --version 2>&1 | Out-String
        if ($pgVersion -match "psql.*?(\d+\.\d+)") {
            Write-Success "PostgreSQL $($matches[1]) detected"
        }
    } catch {
        Write-Warning "PostgreSQL not detected"
        Write-Info "Install from: https://www.postgresql.org/download/windows/"
        $continue = Read-Host "Continue without PostgreSQL? (y/N)"
        if ($continue -ne "y") {
            exit 1
        }
        $SkipDatabase = $true
    }
}

# Check pip
try {
    pip --version | Out-Null
    Write-Success "pip package manager detected"
} catch {
    Write-Error "pip not found! Please ensure pip is installed"
    exit 1
}

Write-Host ""

# Step 2: Create Project Structure
Write-Step "Step 2: Creating Project Structure"
Write-Host ""

if (Test-Path $ProjectPath) {
    Write-Warning "Directory $ProjectPath already exists"
    $overwrite = Read-Host "Overwrite existing directory? (y/N)"
    if ($overwrite -eq "y") {
        Remove-Item -Path $ProjectPath -Recurse -Force
        Write-Success "Removed existing directory"
    } else {
        Write-Info "Using existing directory"
    }
}

# Create directory structure
$directories = @(
    $ProjectPath,
    "$ProjectPath/config",
    "$ProjectPath/apps",
    "$ProjectPath/apps/tenants",
    "$ProjectPath/apps/communities",
    "$ProjectPath/apps/users",
    "$ProjectPath/apps/wiki_custom",
    "$ProjectPath/apps/media_manager",
    "$ProjectPath/templates",
    "$ProjectPath/templates/base",
    "$ProjectPath/templates/tenants",
    "$ProjectPath/templates/communities",
    "$ProjectPath/templates/users",
    "$ProjectPath/static",
    "$ProjectPath/static/css",
    "$ProjectPath/static/js",
    "$ProjectPath/static/images",
    "$ProjectPath/media",
    "$ProjectPath/media/tenant_logos",
    "$ProjectPath/media/avatars",
    "$ProjectPath/logs",
    "$ProjectPath/scripts"
)

foreach ($dir in $directories) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}

Write-Success "Created project directory structure ($($directories.Count) directories)"
Write-Host ""

# Step 3: Create Virtual Environment
Write-Step "Step 3: Creating Virtual Environment"
Write-Host ""

Set-Location $ProjectPath

python -m venv venv
if ($LASTEXITCODE -eq 0) {
    Write-Success "Virtual environment created"
} else {
    Write-Error "Failed to create virtual environment"
    exit 1
}

# Activate virtual environment
& ".\venv\Scripts\Activate.ps1"
Write-Success "Virtual environment activated"
Write-Host ""

# Step 4: Install Dependencies
Write-Step "Step 4: Installing Dependencies"
Write-Host ""

# Create requirements.txt
$requirements = @"
Django==5.0.8
django-tenants==3.6.1
psycopg2-binary==2.9.9
django-wiki==0.12.0
markdown==3.6
django-nyt==1.4.0
django-mptt==0.16.0
django-sekizai==4.1.0
sorl-thumbnail==12.10.0
djangorestframework==3.15.2
django-cors-headers==4.4.0
django-filter==24.3
django-crispy-forms==2.3
crispy-bootstrap5==2024.2
Pillow==10.4.0
python-decouple==3.8
whitenoise==6.7.0
django-extensions==3.2.3
python-slugify==8.0.4
gunicorn==23.0.0
"@

$requirements | Out-File -FilePath "requirements.txt" -Encoding UTF8

if ($Environment -eq "development") {
    $devRequirements = @"
-r requirements.txt
django-debug-toolbar==4.4.6
ipython==8.27.0
pytest==8.3.3
pytest-django==4.9.0
"@
    $devRequirements | Out-File -FilePath "requirements-dev.txt" -Encoding UTF8

    Write-Info "Installing development dependencies..."
    pip install -r requirements-dev.txt --quiet
} else {
    Write-Info "Installing production dependencies..."
    pip install -r requirements.txt --quiet
}

if ($LASTEXITCODE -eq 0) {
    Write-Success "Dependencies installed successfully"
} else {
    Write-Warning "Some dependencies may have failed to install"
}
Write-Host ""

# Step 5: Create Django Project
Write-Step "Step 5: Creating Django Project Structure"
Write-Host ""

# Create manage.py
$managePy = @"
#!/usr/bin/env python
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed?"
        ) from exc
    execute_from_command_line(sys.argv)
"@
$managePy | Out-File -FilePath "manage.py" -Encoding UTF8

Write-Success "Created manage.py"

# Create __init__.py files for all apps
$appDirs = @("config", "apps", "apps/tenants", "apps/communities", "apps/users", "apps/wiki_custom", "apps/media_manager")
foreach ($appDir in $appDirs) {
    New-Item -ItemType File -Path "$appDir/__init__.py" -Force | Out-Null
}

Write-Success "Created Python package structure"
Write-Host ""

# Step 6: Environment Configuration
Write-Step "Step 6: Configuring Environment"
Write-Host ""

# Generate secret key
$secretKey = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 50 | ForEach-Object {[char]$_})

# Create .env file
$envContent = @"
# Django Settings
DEBUG=$($Environment -eq "development")
SECRET_KEY=$secretKey
DJANGO_SETTINGS_MODULE=config.settings

# Database Configuration
DATABASE_ENGINE=django_tenants.postgresql_backend
DATABASE_NAME=$DatabaseName
DATABASE_USER=$DatabaseUser
DATABASE_PASSWORD=$DatabasePassword
DATABASE_HOST=localhost
DATABASE_PORT=5432

# Allowed Hosts
ALLOWED_HOSTS=localhost,127.0.0.1,.localhost,.test

# CORS Settings
CORS_ALLOW_CREDENTIALS=True
CORS_ALLOWED_ORIGINS=http://localhost:8000,http://127.0.0.1:8000

# Cookie Settings
CSRF_COOKIE_DOMAIN=.localhost
SESSION_COOKIE_DOMAIN=.localhost

# Security
SECURE_SSL_REDIRECT=$($Environment -eq "production")
SECURE_HSTS_SECONDS=$($Environment -eq "production" ? "31536000" : "0")
SESSION_COOKIE_SECURE=$($Environment -eq "production")
CSRF_COOKIE_SECURE=$($Environment -eq "production")

# Email
EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend

# Logging
LOG_LEVEL=INFO
"@

$envContent | Out-File -FilePath ".env" -Encoding UTF8
Copy-Item ".env" ".env.example"

Write-Success "Environment configuration created"
Write-Success "Secret key generated (50 characters)"
Write-Host ""

# Step 7: Database Setup
if (-not $SkipDatabase) {
    Write-Step "Step 7: Setting Up Database"
    Write-Host ""

    Write-Info "Attempting to create database: $DatabaseName"

    # Create database using psql
    $createDbCmd = "CREATE DATABASE $DatabaseName;"
    try {
        echo $createDbCmd | psql -U $DatabaseUser -h localhost 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Success "Database $DatabaseName created"
        } else {
            Write-Warning "Database may already exist or access denied"
        }
    } catch {
        Write-Warning "Could not create database automatically"
        Write-Info "Please create database manually: CREATE DATABASE $DatabaseName;"
    }
    Write-Host ""
} else {
    Write-Warning "Skipping database setup"
    Write-Host ""
}

# Step 8: Run Migrations
Write-Step "Step 8: Running Database Migrations"
Write-Host ""

if (-not $SkipDatabase) {
    Write-Info "Running migrations for shared schema..."
    python manage.py migrate_schemas --shared

    if ($LASTEXITCODE -eq 0) {
        Write-Success "Migrations completed successfully"
    } else {
        Write-Warning "Migrations may have failed - check database connection"
    }
} else {
    Write-Info "Skipping migrations (no database configured)"
}
Write-Host ""

# Step 9: Create Superuser
if ($AutoCreateSuperuser -and -not $SkipDatabase) {
    Write-Step "Step 9: Creating Superuser"
    Write-Host ""

    $createSuperuser = @"
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@example.com', 'admin123')
    print('Superuser created: admin / admin123')
else:
    print('Superuser already exists')
"@
    $createSuperuser | python
    Write-Host ""
} else {
    Write-Info "Skipping superuser creation"
    Write-Info "Create manually with: python manage.py createsuperuser"
    Write-Host ""
}

# Step 10: Configure Windows Hosts (Development only)
if ($Environment -eq "development") {
    Write-Step "Step 10: Configuring Windows Hosts File"
    Write-Host ""

    $hostsFile = "C:\Windows\System32\drivers\etc\hosts"

    try {
        # Check if we have admin rights
        $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
        $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

        if ($isAdmin) {
            $hostsEntries = @(
                "127.0.0.1 localhost",
                "127.0.0.1 sample.localhost",
                "127.0.0.1 demo.localhost"
            )

            $hostsContent = Get-Content $hostsFile -ErrorAction SilentlyContinue
            $added = 0

            foreach ($entry in $hostsEntries) {
                if ($hostsContent -notcontains $entry) {
                    Add-Content -Path $hostsFile -Value $entry
                    $added++
                }
            }

            if ($added -gt 0) {
                Write-Success "Added $added entries to hosts file"
            } else {
                Write-Info "Hosts file entries already exist"
            }
        } else {
            Write-Warning "Not running as Administrator"
            Write-Info "To enable subdomain access, add these to $hostsFile :"
            Write-Host "  127.0.0.1 localhost"
            Write-Host "  127.0.0.1 sample.localhost"
            Write-Host "  127.0.0.1 demo.localhost"
        }
    } catch {
        Write-Warning "Could not modify hosts file"
    }
    Write-Host ""
}

# Final Summary
Write-Host ""
Write-ColorOutput "╔══════════════════════════════════════════════════════════════════════╗" "Cyan"
Write-ColorOutput "║                    SETUP COMPLETED SUCCESSFULLY!                     ║" "Cyan"
Write-ColorOutput "╚══════════════════════════════════════════════════════════════════════╝" "Cyan"
Write-Host ""

Write-ColorOutput "📋 Setup Summary:" "Yellow"
Write-Host "   Environment: $Environment" -ForegroundColor White
Write-Host "   Project Path: $(Get-Location)" -ForegroundColor White
Write-Host "   Python Version: $version" -ForegroundColor White
if (-not $SkipDatabase) {
    Write-Host "   Database: $DatabaseName @ localhost:5432" -ForegroundColor White
}
Write-Host ""

Write-ColorOutput "🚀 Next Steps:" "Yellow"
Write-Host ""

if ($Environment -eq "development") {
    Write-ColorOutput "   1. Start Development Server:" "Green"
    Write-Host "      python manage.py runserver 0.0.0.0:8000" -ForegroundColor White
    Write-Host ""
    Write-ColorOutput "   2. Access Your Platform:" "Green"
    Write-Host "      Main Site:        http://localhost:8000" -ForegroundColor Cyan
    Write-Host "      Admin Panel:      http://localhost:8000/admin" -ForegroundColor Cyan
    Write-Host "      Create Community: http://localhost:8000/communities/create/" -ForegroundColor Cyan
    Write-Host ""
    if ($AutoCreateSuperuser) {
        Write-ColorOutput "   3. Login Credentials:" "Green"
        Write-Host "      Username: admin" -ForegroundColor White
        Write-Host "      Password: admin123" -ForegroundColor White
        Write-Host ""
    }
} else {
    Write-ColorOutput "   1. Configure Production Settings:" "Green"
    Write-Host "      - Update .env with production values" -ForegroundColor White
    Write-Host "      - Configure domain and SSL" -ForegroundColor White
    Write-Host "      - Setup Gunicorn and Nginx" -ForegroundColor White
    Write-Host ""
    Write-ColorOutput "   2. Refer to Deployment Guide:" "Green"
    Write-Host "      - See complete-deployment-guide.pdf" -ForegroundColor White
    Write-Host ""
}

Write-ColorOutput "📚 Documentation:" "Yellow"
Write-Host "   - README.md - Quick start guide" -ForegroundColor White
Write-Host "   - complete-deployment-guide.pdf - Full documentation" -ForegroundColor White
Write-Host "   - Interactive guide - Open setup-deployment-guide/index.html" -ForegroundColor White
Write-Host ""

Write-ColorOutput "💡 Helpful Commands:" "Yellow"
Write-Host "   python manage.py createsuperuser              - Create admin user" -ForegroundColor White
Write-Host "   python manage.py migrate_schemas --shared     - Run migrations" -ForegroundColor White
Write-Host "   python manage.py list_tenants                 - List all communities" -ForegroundColor White
Write-Host "   python manage.py collectstatic                - Collect static files" -ForegroundColor White
Write-Host ""

Write-ColorOutput "Need Help? Check the troubleshooting section in the deployment guide!" "Cyan"
Write-Host ""
