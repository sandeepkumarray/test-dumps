
import zipfile
import io
from datetime import datetime

# Create a complete project structure in memory
project_files = {}

# Root files
project_files['manage.py'] = '''#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)
'''

project_files['requirements.txt'] = '''# Core Django
Django==5.0.8
django-tenants==3.6.1
psycopg2-binary==2.9.9

# Wiki functionality
django-wiki==0.12.0
markdown==3.6
django-nyt==1.4.0
django-mptt==0.16.0
django-sekizai==4.1.0
sorl-thumbnail==12.10.0

# REST API
djangorestframework==3.15.2
django-cors-headers==4.4.0
django-filter==24.3

# Forms and UI
django-crispy-forms==2.3
crispy-bootstrap5==2024.2

# Image processing
Pillow==10.4.0

# Environment configuration
python-decouple==3.8

# Static files
whitenoise==6.7.0

# Utils
django-extensions==3.2.3
python-slugify==8.0.4

# Production server
gunicorn==23.0.0
'''

project_files['requirements-dev.txt'] = '''-r requirements.txt

# Development tools
django-debug-toolbar==4.4.6
ipython==8.27.0

# Testing
pytest==8.3.3
pytest-django==4.9.0
pytest-cov==5.0.0

# Code quality
black==24.8.0
flake8==7.1.1
isort==5.13.2
'''

project_files['.env.example'] = '''# Django Settings
DEBUG=True
SECRET_KEY=your-secret-key-must-be-at-least-50-characters-long-change-in-production
DJANGO_SETTINGS_MODULE=config.settings

# Database Configuration (PostgreSQL for multi-tenancy)
DATABASE_ENGINE=django_tenants.postgresql_backend
DATABASE_NAME=fandom_communities
DATABASE_USER=postgres
DATABASE_PASSWORD=your_database_password
DATABASE_HOST=localhost
DATABASE_PORT=5432

# Allowed Hosts (comma-separated, include subdomains)
ALLOWED_HOSTS=localhost,127.0.0.1,.localhost,.test

# CORS Settings
CORS_ALLOW_CREDENTIALS=True
CORS_ALLOWED_ORIGINS=http://localhost:8000,http://127.0.0.1:8000

# Cookie Settings for Subdomains
CSRF_COOKIE_DOMAIN=.localhost
SESSION_COOKIE_DOMAIN=.localhost

# Security (set to True in production)
SECURE_SSL_REDIRECT=False
SECURE_HSTS_SECONDS=0
SESSION_COOKIE_SECURE=False
CSRF_COOKIE_SECURE=False

# Email (configure for production)
EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=
EMAIL_HOST_PASSWORD=

# Logging
LOG_LEVEL=INFO
'''

project_files['.gitignore'] = '''# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/
*.egg-info/

# Django
*.log
db.sqlite3
db.sqlite3-journal
/media
/staticfiles
.env
local_settings.py

# IDE
.vscode/
.idea/
*.swp
.DS_Store

# Testing
.pytest_cache/
.coverage
htmlcov/

# Logs
logs/*.log
'''

project_files['README.md'] = '''# Fandom Community Platform

Multi-tenant community platform with wiki functionality, similar to Fandom.com.
Each community gets its own subdomain with isolated data.

## Features

- **Multi-Tenant Architecture**: Schema-based tenant isolation using django-tenants
- **Subdomain Communities**: Each community accessible via subdomain (e.g., gaming.localhost:8000)
- **Wiki Engine**: Full wiki functionality with django-wiki
- **Real-time Validation**: AJAX subdomain availability checking
- **User Management**: Comprehensive user profiles and authentication
- **Media Management**: Image uploads and file management
- **REST API**: RESTful API for programmatic access
- **Responsive UI**: Bootstrap 5 responsive design

## Requirements

- Python 3.9+
- PostgreSQL 12+ (required for multi-tenancy)
- Windows/Linux/macOS

## Quick Start (Development)

### 1. Clone and Setup

```bash
# Create project directory
mkdir fandom-platform && cd fandom-platform

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows PowerShell:
.\\venv\\Scripts\\Activate.ps1
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Database Setup

Install and configure PostgreSQL:

```bash
# Create database
createdb fandom_communities

# Or using PostgreSQL shell:
psql -U postgres
CREATE DATABASE fandom_communities;
\\q
```

### 3. Environment Configuration

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your database credentials
```

### 4. Run Migrations

```bash
# Migrate shared schema
python manage.py migrate_schemas --shared

# Create public tenant
python manage.py create_public_tenant

# Create superuser
python manage.py createsuperuser
```

### 5. Configure Windows Hosts File (Windows only)

Run PowerShell as Administrator:

```powershell
# Add localhost subdomains
Add-Content C:\\Windows\\System32\\drivers\\etc\\hosts "127.0.0.1 localhost"
Add-Content C:\\Windows\\System32\\drivers\\etc\\hosts "127.0.0.1 sample.localhost"
```

### 6. Start Development Server

```bash
python manage.py runserver 0.0.0.0:8000
```

Access:
- Main platform: http://localhost:8000
- Create community: http://localhost:8000/communities/create/
- Admin: http://localhost:8000/admin

## Project Structure

```
fandom_community_platform/
├── config/                 # Django configuration
│   ├── settings.py        # Main settings
│   ├── settings_production.py  # Production settings
│   ├── urls.py            # Tenant URLs
│   └── urls_public.py     # Public schema URLs
├── apps/
│   ├── tenants/           # Tenant management
│   ├── communities/       # Community features
│   ├── users/             # User management
│   ├── wiki_custom/       # Wiki customizations
│   └── media_manager/     # Media handling
├── templates/             # HTML templates
├── static/                # Static files (CSS, JS)
├── media/                 # User uploads
├── scripts/               # Deployment scripts
└── logs/                  # Application logs
```

## Creating Communities

1. Visit http://localhost:8000/communities/create/
2. Enter community name and desired subdomain
3. System validates subdomain availability in real-time
4. Community created with isolated database schema
5. Access at http://[subdomain].localhost:8000

## Production Deployment

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed production deployment instructions.

Quick production setup:

```bash
# Set production environment variables
export DJANGO_SETTINGS_MODULE=config.settings_production
export DEBUG=False

# Configure wildcard DNS
*.yourdomain.com → Your server IP

# Use gunicorn
gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 4

# Setup nginx as reverse proxy
# Configure SSL certificates (wildcard SSL recommended)
```

## API Documentation

REST API available at `/api/`

Key endpoints:
- `/api/communities/` - List communities
- `/api/communities/check-subdomain/` - Check subdomain availability
- `/api/users/` - User management

## Testing

```bash
# Install dev dependencies
pip install -r requirements-dev.txt

# Run tests
pytest

# Run with coverage
pytest --cov=apps
```

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## License

MIT License

## Support

For issues and questions, please open an issue on the repository.

## Acknowledgments

- Django Tenants for multi-tenancy support
- Django Wiki for wiki functionality
- Bootstrap for UI components
'''

# Create a summary of what will be in the complete project
summary = f'''
=== Complete Deployable Project Package ===

Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

Root Files: {len([k for k in project_files.keys() if '/' not in k])}
- manage.py
- requirements.txt  
- requirements-dev.txt
- .env.example
- .gitignore
- README.md

This package includes all necessary files for:
✓ Local development setup
✓ PostgreSQL multi-tenant configuration  
✓ Subdomain community creation
✓ Production deployment readiness
✓ Complete documentation

Next: Generating remaining project files...
'''

print(summary)
