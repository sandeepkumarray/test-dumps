
import zipfile
from io import BytesIO
import base64

# Create comprehensive project ZIP
zip_buffer = BytesIO()

with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
    
    # Root files
    zipf.writestr('fandom_community_platform/manage.py', '''#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)
''')

    zipf.writestr('fandom_community_platform/requirements.txt', '''Django==5.0.8
django-tenants==3.6.1
psycopg2-binary==2.9.9
django-wiki==0.12.0
markdown==3.6
django-nyt==1.4.0
django-mptt==0.16.0
django-sekizai==4.1.0
sorl-thumbnail==12.10.0
djangorestframework==3.15.2
django-cors-headers==4.4.0
django-filter==24.3
django-crispy-forms==2.3
crispy-bootstrap5==2024.2
Pillow==10.4.0
python-decouple==3.8
whitenoise==6.7.0
django-extensions==3.2.3
python-slugify==8.0.4
gunicorn==23.0.0
''')

    zipf.writestr('fandom_community_platform/requirements-dev.txt', '''-r requirements.txt
django-debug-toolbar==4.4.6
ipython==8.27.0
pytest==8.3.3
pytest-django==4.9.0
pytest-cov==5.0.0
black==24.8.0
flake8==7.1.1
isort==5.13.2
''')

    env_content = '''# Django Settings
DEBUG=True
SECRET_KEY=django-insecure-change-this-to-50-character-random-string-in-production-now
DJANGO_SETTINGS_MODULE=config.settings

# Database Configuration
DATABASE_ENGINE=django_tenants.postgresql_backend
DATABASE_NAME=fandom_communities
DATABASE_USER=postgres
DATABASE_PASSWORD=your_secure_password_here
DATABASE_HOST=localhost
DATABASE_PORT=5432

# Allowed Hosts (comma-separated)
ALLOWED_HOSTS=localhost,127.0.0.1,.localhost,.test

# CORS Settings
CORS_ALLOW_CREDENTIALS=True
CORS_ALLOWED_ORIGINS=http://localhost:8000,http://127.0.0.1:8000

# Cookie Settings for Subdomains
CSRF_COOKIE_DOMAIN=.localhost
SESSION_COOKIE_DOMAIN=.localhost

# Security (Production only)
SECURE_SSL_REDIRECT=False
SECURE_HSTS_SECONDS=0
SESSION_COOKIE_SECURE=False
CSRF_COOKIE_SECURE=False

# Email Configuration
EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=
EMAIL_HOST_PASSWORD=
DEFAULT_FROM_EMAIL=noreply@example.com

# Logging
LOG_LEVEL=INFO
'''
    zipf.writestr('fandom_community_platform/.env.example', env_content)

    gitignore = '''__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/
*.egg-info/
*.log
db.sqlite3
db.sqlite3-journal
/media
/staticfiles
.env
local_settings.py
.vscode/
.idea/
*.swp
.DS_Store
.pytest_cache/
.coverage
htmlcov/
logs/*.log
'''
    zipf.writestr('fandom_community_platform/.gitignore', gitignore)

print("✓ Root configuration files added")
print("Continuing with Django configuration...")
