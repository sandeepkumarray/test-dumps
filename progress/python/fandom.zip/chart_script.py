import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# Since mermaid service is unavailable, let's create a comprehensive project overview using Plotly
# Create a network-style visualization showing project components and relationships

# Define the project structure data
components = {
    'Central Hub': {'x': 0, 'y': 0, 'color': '#1FB8CD', 'size': 60, 'category': 'Hub'},
    
    # Documentation Branch
    'Documentation': {'x': -3, 'y': 2, 'color': '#2E8B57', 'size': 40, 'category': 'Main'},
    'Deploy Guide': {'x': -5, 'y': 3, 'color': '#2E8B57', 'size': 25, 'category': 'Doc'},
    'Deliverables': {'x': -4, 'y': 4, 'color': '#2E8B57', 'size': 25, 'category': 'Doc'},
    'Web Guide': {'x': -3, 'y': 4.5, 'color': '#2E8B57', 'size': 25, 'category': 'Doc'},
    
    # Setup Tools Branch
    'Setup Tools': {'x': -2, 'y': -3, 'color': '#DB4545', 'size': 40, 'category': 'Main'},
    'PowerShell': {'x': -4, 'y': -4, 'color': '#DB4545', 'size': 25, 'category': 'Setup'},
    'Web Wizard': {'x': -2, 'y': -5, 'color': '#DB4545', 'size': 25, 'category': 'Setup'},
    'Templates': {'x': -1, 'y': -4.5, 'color': '#DB4545', 'size': 25, 'category': 'Setup'},
    
    # Source Code Branch
    'Source Code': {'x': 3, 'y': 2, 'color': '#5D878F', 'size': 40, 'category': 'Main'},
    'Django Core': {'x': 5, 'y': 3, 'color': '#5D878F', 'size': 25, 'category': 'Code'},
    'Tenant Apps': {'x': 4, 'y': 4, 'color': '#5D878F', 'size': 25, 'category': 'Code'},
    'User System': {'x': 3, 'y': 4.5, 'color': '#5D878F', 'size': 25, 'category': 'Code'},
    'Frontend': {'x': 2, 'y': 4, 'color': '#5D878F', 'size': 25, 'category': 'Code'},
    
    # Database Branch
    'Database': {'x': 2, 'y': -3, 'color': '#D2BA4C', 'size': 40, 'category': 'Main'},
    'PostgreSQL': {'x': 4, 'y': -4, 'color': '#D2BA4C', 'size': 25, 'category': 'DB'},
    'Public Schema': {'x': 2, 'y': -5, 'color': '#D2BA4C', 'size': 25, 'category': 'DB'},
    'Tenant Schema': {'x': 1, 'y': -4.5, 'color': '#D2BA4C', 'size': 25, 'category': 'DB'},
    
    # Deployment Targets
    'Development': {'x': -1, 'y': 1, 'color': '#B4413C', 'size': 30, 'category': 'Deploy'},
    'Production': {'x': 1, 'y': 1, 'color': '#B4413C', 'size': 30, 'category': 'Deploy'},
}

# Define connections
connections = [
    # From Central Hub
    ('Central Hub', 'Documentation'),
    ('Central Hub', 'Setup Tools'),
    ('Central Hub', 'Source Code'),
    ('Central Hub', 'Database'),
    ('Central Hub', 'Development'),
    ('Central Hub', 'Production'),
    
    # Documentation connections
    ('Documentation', 'Deploy Guide'),
    ('Documentation', 'Deliverables'),
    ('Documentation', 'Web Guide'),
    
    # Setup Tools connections
    ('Setup Tools', 'PowerShell'),
    ('Setup Tools', 'Web Wizard'),
    ('Setup Tools', 'Templates'),
    
    # Source Code connections
    ('Source Code', 'Django Core'),
    ('Source Code', 'Tenant Apps'),
    ('Source Code', 'User System'),
    ('Source Code', 'Frontend'),
    
    # Database connections
    ('Database', 'PostgreSQL'),
    ('Database', 'Public Schema'),
    ('Database', 'Tenant Schema'),
    
    # Key relationships
    ('PowerShell', 'PostgreSQL'),
    ('PowerShell', 'Development'),
    ('Django Core', 'PostgreSQL'),
]

# Create the figure
fig = go.Figure()

# Add connection lines first (so they appear behind nodes)
for start, end in connections:
    if start in components and end in components:
        fig.add_trace(go.Scatter(
            x=[components[start]['x'], components[end]['x']],
            y=[components[start]['y'], components[end]['y']],
            mode='lines',
            line=dict(color='rgba(100,100,100,0.3)', width=1),
            showlegend=False,
            hoverinfo='skip'
        ))

# Add nodes by category for better legend organization
categories = ['Hub', 'Main', 'Doc', 'Setup', 'Code', 'DB', 'Deploy']
category_names = {
    'Hub': 'Central Platform',
    'Main': 'Core Components', 
    'Doc': 'Documentation',
    'Setup': 'Setup Tools',
    'Code': 'Source Code',
    'DB': 'Database',
    'Deploy': 'Deployment'
}

for category in categories:
    # Get components for this category
    cat_components = {name: info for name, info in components.items() 
                     if info['category'] == category}
    
    if cat_components:
        x_vals = [info['x'] for info in cat_components.values()]
        y_vals = [info['y'] for info in cat_components.values()]
        sizes = [info['size'] for info in cat_components.values()]
        colors = [info['color'] for info in cat_components.values()]
        names = list(cat_components.keys())
        
        fig.add_trace(go.Scatter(
            x=x_vals,
            y=y_vals,
            mode='markers+text',
            marker=dict(
                size=sizes,
                color=colors,
                line=dict(width=2, color='white'),
                opacity=0.9
            ),
            text=names,
            textposition='middle center',
            textfont=dict(size=8, color='white', family='Arial Black'),
            name=category_names[category],
            hovertemplate='<b>%{text}</b><br>Component Type: ' + category_names[category] + '<extra></extra>'
        ))

# Update layout
fig.update_layout(
    title='Fandom Platform - Project Overview',
    showlegend=True,
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    ),
    xaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[-6, 6]
    ),
    yaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[-6, 5.5]
    ),
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)'
)

# Save the chart
fig.write_image("project_overview.png")
fig.write_image("project_overview.svg", format="svg")

print("Project overview chart created successfully!")