
# Generate all project files

files_content = {}

# 1. manage.py
files_content['manage.py'] = """#!/usr/bin/env python
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)
"""

# 2. requirements.txt
files_content['requirements.txt'] = """# Core Django
Django==5.0.8
django-tenants==3.6.1
psycopg2-binary==2.9.9

# Wiki functionality
django-wiki==0.12.0
wiki==0.10.0
markdown==3.6
django-nyt==1.4.0
django-mptt==0.16.0
django-sekizai==4.1.0
sorl-thumbnail==12.10.0

# REST API
djangorestframework==3.15.2
django-cors-headers==4.4.0
django-filter==24.3

# Forms and UI
django-crispy-forms==2.3
crispy-bootstrap5==2024.2

# Image processing
Pillow==10.4.0

# Environment configuration
python-decouple==3.8

# Static files
whitenoise==6.7.0

# Utils
django-extensions==3.2.3
python-slugify==8.0.4

# Production server
gunicorn==23.0.0
"""

# 3. requirements-dev.txt
files_content['requirements-dev.txt'] = """# Development requirements (in addition to requirements.txt)
-r requirements.txt

# Debugging
django-debug-toolbar==4.4.6
ipython==8.27.0

# Testing
pytest==8.3.3
pytest-django==4.9.0
pytest-cov==5.0.0
factory-boy==3.3.1

# Code quality
black==24.8.0
flake8==7.1.1
pylint==3.3.0
isort==5.13.2

# Documentation
Sphinx==8.0.2
sphinx-rtd-theme==2.0.0
"""

# 4. .env.example
files_content['.env.example'] = """# Django Settings
DEBUG=True
SECRET_KEY=your-secret-key-change-this-in-production-min-50-chars-long
DJANGO_SETTINGS_MODULE=config.settings

# Database Configuration
DATABASE_ENGINE=django_tenants.postgresql_backend
DATABASE_NAME=fandom_communities
DATABASE_USER=postgres
DATABASE_PASSWORD=your_database_password
DATABASE_HOST=localhost
DATABASE_PORT=5432

# For development with SQLite (comment out PostgreSQL settings above)
# DATABASE_ENGINE=django.db.backends.sqlite3
# DATABASE_NAME=db.sqlite3

# Allowed Hosts (comma-separated)
ALLOWED_HOSTS=localhost,127.0.0.1,.localhost,.test

# CORS Settings
CORS_ALLOW_CREDENTIALS=True
CORS_ALLOWED_ORIGINS=http://localhost:8000,http://127.0.0.1:8000

# Cookie Settings for Subdomains
CSRF_COOKIE_DOMAIN=.localhost
SESSION_COOKIE_DOMAIN=.localhost

# Media and Static Files
MEDIA_ROOT=media
STATIC_ROOT=staticfiles

# Email Configuration (for production)
EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=your-email@example.com
EMAIL_HOST_PASSWORD=your-email-password

# Production Settings
SECURE_SSL_REDIRECT=False
SECURE_HSTS_SECONDS=0
SECURE_HSTS_INCLUDE_SUBDOMAINS=False
SESSION_COOKIE_SECURE=False
CSRF_COOKIE_SECURE=False

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/django.log
"""

# 5. .gitignore
files_content['.gitignore'] = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Virtual Environment
venv/
env/
ENV/
env.bak/
venv.bak/

# Django
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal
/media
/staticfiles
/static_collected

# Environment
.env
.env.local
.env.production

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.DS_Store

# Testing
.pytest_cache/
.coverage
htmlcov/
.tox/

# Documentation
docs/_build/
site/

# Database backups
*.sql
*.dump

# Logs
logs/*.log
"""

# Save file count
print(f"Generated {len(files_content)} root configuration files")
print("Files created:", list(files_content.keys()))
